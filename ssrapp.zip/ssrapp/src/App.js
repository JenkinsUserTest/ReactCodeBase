
import React from 'react';
import Home from './Home';
class App extends React.Component{

render(){
  return(
    <Home companyName="Yash Technologies"/>
  );
}
}
export default App;
