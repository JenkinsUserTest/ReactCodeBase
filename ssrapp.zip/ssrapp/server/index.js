import path from 'path';
import fs from 'fs';
import React from 'react';
import express from 'express';
import ReactDOMServer from 'react-dom/server';
import App from '../src/App';
const PORT=3006
const app=express();
app.get('/*',(req,res)=>{

console.log("***in get*****");
const app=ReactDOMServer.renderToString(<App/>);
console.log(app);
const indexFile=path.resolve('./build/index.html');
fs.readFile(indexFile,'utf8',(err,data)=>{
    console.log("***in read file*********");
    if(err){
        console.error('Error!!!');
        return res.status(500).send('Error processing request');
    }
    return res.send(
     data.replace('<div id="root"></div>','<div id="root">'+app+'</div>')
    );
})
});

app.use(express.static('./build'));

app.listen(PORT,()=>{
    console.log('Server is listening on port'+PORT);
})