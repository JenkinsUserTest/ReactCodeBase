//export an array
export let months=['Jan','Feb','Mar'];

//export a constant

export const YEAR=2020;

//export a class

export class User{

    constructor(name){
        this.name=name;
    }
}