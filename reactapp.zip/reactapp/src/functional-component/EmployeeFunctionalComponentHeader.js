import React from 'react';
function EmployeeFunctionalComponentHeader(){
    return <p>Employee Information</p>;
}
export default EmployeeFunctionalComponentHeader;