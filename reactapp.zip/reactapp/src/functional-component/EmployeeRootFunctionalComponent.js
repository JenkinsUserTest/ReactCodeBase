import React from 'react';
import EmployeeFunctionalComponentHeader from './EmployeeFunctionalComponentHeader';
function EmployeeRootFunctionalComponent(){
    return <EmployeeFunctionalComponentHeader/>;
}
export default EmployeeRootFunctionalComponent;