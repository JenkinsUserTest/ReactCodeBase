import React from 'react';
function ChildFunctionalComponent(props){
return <h1>{props.value}</h1>
}
export default ChildFunctionalComponent;