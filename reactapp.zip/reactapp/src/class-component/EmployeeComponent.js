import React from 'react';
class EmployeeComponent extends React.Component{
    render(){
        return (
        <div>
        <h1>Yash Technologies</h1>
        <p>Employee Information</p>
        </div>
        );
    }
}
export default EmployeeComponent;