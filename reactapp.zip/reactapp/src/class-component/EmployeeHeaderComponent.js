import React from 'react';
class EmployeeHeaderComponent extends React.Component{
    render(){
        return <p>Employee Information</p>;
    }
}
export default EmployeeHeaderComponent;