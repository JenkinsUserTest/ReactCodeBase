import React from 'react';
class EmployeeProfessionalDetailsComponent extends React.Component{
    render(){
        return <p>Employee Professional Details</p>;
    }
}
export default EmployeeProfessionalDetailsComponent;