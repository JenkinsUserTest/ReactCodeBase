import React from 'react';
class EmployeePersonalDetailsComponent extends React.Component{

    render(){
        return <p>Employee Personal Details</p>
    }
}
export default EmployeePersonalDetailsComponent;